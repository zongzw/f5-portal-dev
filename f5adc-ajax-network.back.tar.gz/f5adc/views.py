# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from django.conf import settings
from django.core.urlresolvers import reverse
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import forms
from horizon import messages
from horizon import tables
from horizon.utils import memoized
from horizon import workflows

from openstack_dashboard import api
from openstack_dashboard import policy

from openstack_dashboard.dashboards.identity.groups import constants
from openstack_dashboard.dashboards.f5services.f5adc \
    import forms as adc_forms

from openstack_dashboard.dashboards.f5services.f5adc \
    import tables as adc_tables
from openstack_dashboard.dashboards.f5services.f5adc \
    import workflows as adc_workflows
from openstack_dashboard.utils import identity

class IndexView(tables.DataTableView):
    # A very simple class-based view...

    table_class = adc_tables.ADCsTable
    page_title = _("F5 ADC Management")
    #template_name = constants.GROUPS_INDEX_VIEW_TEMPLATE
    template_name = 'f5services/f5adc/index.html'

    # def get_data(self, request, context, *args, **kwargs):
    #     # Add data to the context here...
    #     return context

    # def needs_filter_first(self, table):
    #         return self._needs_filter_first

    def get_data(self):
        # groups = []
        # filters = self.get_filters()
        # self._needs_filter_first = False

        # if policy.check((("identity", "identity:list_groups"),),
        #                 self.request):

        #     # If filter_first is set and if there are not other filters
        #     # selected, then search criteria must be provided and
        #     # return an empty list
        #     filter_first = getattr(settings, 'FILTER_DATA_FIRST', {})
        #     if filter_first.get('identity.groups', False) \
        #             and len(filters) == 0:
        #         self._needs_filter_first = True
        #         return groups

        #     domain_id = identity.get_domain_id_for_operation(self.request)
        #     try:
        #         groups = api.keystone.group_list(self.request,
        #                                             domain=domain_id,
        #                                             filters=filters)
        #         print(self.request.user.token.id)
        #     except Exception:
        #         exceptions.handle(self.request,
        #                             _('Unable to retrieve group list.'))
        # else:
        #     msg = _("Insufficient privilege level to view group information.")
        #     messages.info(self.request, msg)
        return []

class CreateADCView(workflows.WorkflowView):
    # template_name = 'f5services/f5adc/create.html'
    # form_id = "create_adc_form"
    # form_class = adc_forms.CreateADCForm
    # submit_label = _("Create ADC")
    # submit_url = reverse_lazy('horizon:f5services:f5adc:create')
    # success_url = reverse_lazy('horizon:f5services:f5adc:index')
    # page_title = _("Create ADC")

    workflow_class = adc_workflows.CreateADC

    def get_initial(self):
        initial = super(CreateADCView, self).get_initial()
        initial['project_id'] = self.request.user.tenant_id
        initial['user_id'] = self.request.user.id
        # defaults = getattr(settings, 'LAUNCH_INSTANCE_DEFAULTS', {})
        # initial['config_drive'] = defaults.get('config_drive', False)
        return initial