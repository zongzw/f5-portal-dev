import logging
from operator import itemgetter

from django.conf import settings
from django.utils.translation import ugettext_lazy as _
import six

from horizon import exceptions

from openstack_dashboard import api

LOG = logging.getLogger(__name__)


def network_field_data(request, include_empty_option=False, with_cidr=False):
    """Returns a list of tuples of all networks.

    Generates a list of networks available to the user (request). And returns
    a list of (id, name) tuples.

    :param request: django http request object
    :param include_empty_option: flag to include a empty tuple in the front of
         the list
    :param with_cidr: flag to include subnets cidr in field name
    :return: list of (id, name) tuples
    """
    tenant_id = request.user.tenant_id
    networks = []
    if api.base.is_service_enabled(request, 'network'):
        try:
            networks = api.neutron.network_list_for_tenant(request, tenant_id)
        except Exception as e:
            msg = _('Failed to get network list {0}').format(six.text_type(e))
            exceptions.handle(request, msg)

        _networks = []
        for n in networks:
            if not n['subnets']:
                continue
            v = n.name_or_id
            if with_cidr:
                cidrs = ([subnet.cidr for subnet in n['subnets']
                          if subnet.ip_version == 4] +
                         [subnet.cidr for subnet in n['subnets']
                          if subnet.ip_version == 6])
                v += ' (%s)' % ', '.join(cidrs)
            _networks.append((n.id, v))
        networks = sorted(_networks, key=itemgetter(1))

    if not networks:
        if include_empty_option:
            return [("", _("No networks available")), ]
        return []

    if include_empty_option:
        return [("", _("Select Network")), ] + networks
    return networks
