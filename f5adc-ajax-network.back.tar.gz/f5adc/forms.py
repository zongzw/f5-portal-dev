
import logging

from django.utils.translation import ugettext_lazy as _

from horizon import exceptions
from horizon import forms
from horizon import messages

from openstack_dashboard import api
from openstack_dashboard.utils import identity as identity_utils


LOG = logging.getLogger(__name__)


class CreateADCForm(forms.SelfHandlingForm):
    name = forms.CharField(label=_("Name"),
                           max_length=64)
    description = forms.CharField(widget=forms.widgets.Textarea(
                                  attrs={'rows': 4}),
                                  label=_("Description"),
                                  required=False)

    def handle(self, request, data):
        try:
            LOG.info('Creating adc with name "%s"', data['name'])
            # api.keystone.group_create(
            #     request,
            #     domain_id=identity_utils.get_domain_id_for_operation(
            #         self.request),
            #     name=data['name'],
            #     description=data['description'])
            # TODO: create ADC with api.
            messages.success(request,
                             _('ADC "%s" was successfully created.')
                             % data['name'])
        except Exception:
            exceptions.handle(request, _('Unable to create ADC.'))
            return False
        return True