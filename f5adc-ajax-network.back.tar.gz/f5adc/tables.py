import logging

from django.core.urlresolvers import reverse
from django.template import defaultfilters
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ungettext_lazy
from django import template

from horizon import tables
from horizon.templatetags import sizeformat
from horizon.utils import filters

from openstack_dashboard import api
# from openstack_dashboard.dashboards.identity.groups import constants
from openstack_dashboard import policy

LOG = logging.getLogger(__name__)
LOGOUT_URL = 'logout'
STATUS_CHOICES = (
    ("true", True),
    ("false", False)
)

class ADCFilterAction(tables.FilterAction):
    filter_type = "server"
    filter_choices = (("name", _("ADC Name ="), True),
                      ("id", _("ADC ID ="), True))

class DeleteADCsAction(policy.PolicyTargetMixin, tables.DeleteAction):
    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Delete ADC",
            u"Delete ADCs",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Deleted ADC",
            u"Deleted ADCs",
            count
        )

    policy_rules = (("identity", "identity:delete_adc"),)

    def allowed(self, request, datum):
        return api.keystone.keystone_can_edit_adc()

    def delete(self, request, obj_id):
        LOG.info('Deleting adc "%s".', obj_id)
        #api.keystone.group_delete(request, obj_id)
        # TODO: api.adcaas.adc_delete(request, obj_id)

class CreateADCLink(tables.LinkAction):
    name = "create"
    verbose_name = _("Create ADC")
    url = "horizon:f5services:f5adc:create"
    classes = ("ajax-modal",)
    icon = "plus"
    policy_rules = (("identity", "identity:create_adc"),)

    def allowed(self, request, group):
        return api.keystone.keystone_can_edit_adc()

def get_flavor(instance):
    if hasattr(instance, "full_flavor"):
        template_name = 'f5services/f5adc/_instance_flavor.html'
        size_ram = sizeformat.mb_float_format(instance.full_flavor.ram)
        if instance.full_flavor.disk > 0:
            size_disk = sizeformat.diskgbformat(instance.full_flavor.disk)
        else:
            size_disk = _("%s GB") % "0"
        context = {
            "name": instance.full_flavor.name,
            "id": instance.id,
            "size_disk": size_disk,
            "size_ram": size_ram,
            "vcpus": instance.full_flavor.vcpus,
            "flavor_id": instance.full_flavor.id
        }
        return template.loader.render_to_string(template_name, context)
    return _("Not available")

class ADCsTable(tables.DataTable):
    name = tables.Column('name', verbose_name=_('Name'))
    description = tables.Column(lambda obj: getattr(obj, 'description', None),
                                verbose_name=_('Description'))
    #id = tables.Column('id', verbose_name=_('ADC ID'))

    image_name = tables.WrappingColumn("image_name",
                                       verbose_name=_("Image Name"))

    flavor = tables.Column(get_flavor,
                           sortable=False,
                           verbose_name=_("Flavor"))
    # keypair = tables.Column(get_keyname, verbose_name=_("Key Pair"))
    # status = tables.Column("status",
    #                        filters=(title, filters.replace_underscores),
    #                        verbose_name=_("Status"),
    #                        status=True,
    #                        status_choices=STATUS_CHOICES,
    #                        display_choices=STATUS_DISPLAY_CHOICES)
    # locked = tables.Column(render_locked,
    #                        verbose_name="",
    #                        sortable=False)
    # az = tables.Column("availability_zone",
    #                    verbose_name=_("Availability Zone"))
    # task = tables.Column("OS-EXT-STS:task_state",
    #                      verbose_name=_("Task"),
    #                      empty_value=TASK_DISPLAY_NONE,
    #                      status=True,
    #                      status_choices=TASK_STATUS_CHOICES,
    #                      display_choices=TASK_DISPLAY_CHOICES)
    # state = tables.Column(get_power_state,
    #                       filters=(title, filters.replace_underscores),
    #                       verbose_name=_("Power State"),
    #                       display_choices=POWER_DISPLAY_CHOICES)
    created = tables.Column("created",
                            verbose_name=_("Time since created"),
                            filters=(filters.parse_isotime,
                                     filters.timesince_sortable),
                            attrs={'data-type': 'timesince'})
                            
    class Meta(object):
        name = "adcs"
        verbose_name = _("ADCs")
        row_actions = ()
        # row_actions = (ManageUsersLink, EditGroupLink, DeleteGroupsAction)
        table_actions = (ADCFilterAction, CreateADCLink,
                         DeleteADCsAction)




